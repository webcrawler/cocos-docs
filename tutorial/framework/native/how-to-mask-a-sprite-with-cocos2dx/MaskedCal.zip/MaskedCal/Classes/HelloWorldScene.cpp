#include "HelloWorldScene.h"

USING_NS_CC;


//init static variable
int HelloWorld::calendarNum = 0;

// Replace createScene() scene with the following
Scene* HelloWorld::sceneWithLastCalendar(int lastCalendar)
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::layerWithLastCalendar(lastCalendar);
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

Layer* HelloWorld::layerWithLastCalendar(int lastCalendar)
{
    HelloWorld *pRet = new HelloWorld();
    if (pRet && pRet->init())
    {
        pRet->autorelease();

        do {
            calendarNum =  (arc4random() % 3) + 1;
        } while (calendarNum == lastCalendar);
        
        Size winSize = Director::getInstance()->getWinSize();
        
        char spriteName[100] = {0};
        sprintf(spriteName, "Calendar%d.png", calendarNum);
        
        Sprite * cal = Sprite::create(spriteName);

        //cal->setPosition(visibleSize.width/2, visibleSize.height/2);
        
        Sprite * mask = Sprite::create("CalendarMask.png");
        Sprite * maskedCal = maskedSpriteWithSprite(cal, mask);
        maskedCal->setPosition(winSize.width/2, winSize.height/2);
        //pRet->addChild(cal);
        pRet->addChild(maskedCal);
        
        return pRet;
    }
    else
    {
        delete pRet;
        pRet = NULL;
        return NULL;
    }
}

Sprite* HelloWorld::maskedSpriteWithSprite(Sprite* textureSprite, Sprite* maskSprite)
{
    // 1
    RenderTexture * rt = RenderTexture::create( maskSprite->getContentSize().width,
                                               maskSprite->getContentSize().height );
    
    // 2
    maskSprite->setPosition(maskSprite->getContentSize().width/2,
                            maskSprite->getContentSize().height/2);
    textureSprite->setPosition(textureSprite->getContentSize().width/2,
                               textureSprite->getContentSize().height/2);
    
    // 3
    maskSprite->setBlendFunc( BlendFunc{GL_ONE, GL_ZERO} );
    textureSprite->setBlendFunc( BlendFunc{GL_DST_ALPHA, GL_ZERO} );
    
    // 4
    rt->begin();
    maskSprite->visit();
    textureSprite->visit();
    rt->end();
    
    // 5
    Sprite *retval = Sprite::createWithTexture(rt->getSprite()->getTexture());
    retval->setFlippedY(true);
    return retval;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
    
    return true;
}


bool HelloWorld::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
    Scene *scene = HelloWorld::sceneWithLastCalendar(calendarNum);
    Director::getInstance()->replaceScene(TransitionJumpZoom::create(1.0f, scene));

    return true;
}

void HelloWorld::onTouchMoved(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
}

void HelloWorld::onTouchEnded(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
}